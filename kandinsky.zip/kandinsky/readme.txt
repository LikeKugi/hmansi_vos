== Changelog ==

= 2.2.0 =
* Improved compatibility with WordPress 6.0
* Added Filter Campaigns by type.
* Add ToggleControl "Open in new tab" for button in CTA block.
* Add control to select columns in blocks News and Projects.
* Move Campaigns Cards block from theme to Leyka category section.
* Transform deprecated block Donation Form from theme to same block from Leyka plugin.
* Added settings controls to disable buttons on the single campaign page.
* Add Query controls for blocks News, Projects, Partners, Team and Events.
* Added support for categories for projects and created functionality for separating completed projects.
* Added to top button.
* Add Heading level option for hero block title.
* Improve function scroll to anchor.
* Added the ability to add an anchor for blocks.
* Add Comments Template.

= 2.0.0 =
* Official release version 2.0!
